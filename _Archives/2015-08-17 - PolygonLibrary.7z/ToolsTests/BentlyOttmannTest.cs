﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;

using PolygonLibrary;

namespace ToolsTests
{
  [TestClass]
  public class BentlyOttmannTest
  {
    [TestMethod]
    public void BOTest ()
    {
      List<Segment> segs = new List<Segment>();
      segs.Add (new Segment (6, 3, 0, 0));
      segs.Add (new Segment (2.5, 0, 1, 3));

      SortedSet<SegmentPair> neighs = new SortedSet<SegmentPair>();
      
      SegmentCrosser crosser = new SegmentCrosser (segs, neighs);
      Assert.IsTrue (crosser.Count <= 1, "Test #01: too many crossings!");
      Assert.IsTrue (crosser.Count >= 1, "Test #01: too few crossings!");

      segs.Add (new Segment (2, -2, 5, 4));
      crosser = new SegmentCrosser (segs, neighs);
      Assert.IsTrue (crosser.Count <= 2, "Test #02: too many crossings!");
      Assert.IsTrue (crosser.Count >= 2, "Test #02: too few crossings!");

      segs.Add (new Segment (-1, -2, -1, 5));
      crosser = new SegmentCrosser (segs, neighs);
      Assert.IsTrue (crosser.Count <= 2, "Test #03: too many crossings!");
      Assert.IsTrue (crosser.Count >= 2, "Test #03: too few crossings!");

      segs.Add (new Segment (-1, -3, -1, -1));
      crosser = new SegmentCrosser (segs, neighs);
      Assert.IsTrue (crosser.Count <= 4, "Test #04: too many crossings!");
      Assert.IsTrue (crosser.Count >= 4, "Test #04: too few crossings!");

      segs.Add (new Segment (-1, 1, -1, 2));
      crosser = new SegmentCrosser (segs, neighs);
      Assert.IsTrue (crosser.Count <= 6, "Test #05: too many crossings!");
      Assert.IsTrue (crosser.Count >= 6, "Test #05: too few crossings!");

      segs.Add (new Segment (-1, 2, -1, 3));
      crosser = new SegmentCrosser (segs, neighs);
      Assert.IsTrue (crosser.Count <= 9, "Test #06: too many crossings!");
      Assert.IsTrue (crosser.Count >= 9, "Test #06: too few crossings!");

      neighs.Add (new SegmentPair (segs[segs.Count-1], segs[segs.Count-2]));
      crosser = new SegmentCrosser (segs, neighs);
      Assert.IsTrue (crosser.Count <= 8, "Test #07: too many crossings!");
      Assert.IsTrue (crosser.Count >= 8, "Test #07: too few crossings!");

      segs.Add (new Segment (-2, 1, 0, 1));
      crosser = new SegmentCrosser (segs, neighs);
      Assert.IsTrue (crosser.Count <= 10, "Test #08: too many crossings!");
      Assert.IsTrue (crosser.Count >= 10, "Test #08: too few crossings!");

      segs.Add (new Segment (0, -1, 0, 2));
      segs.Add (new Segment (0, -2, 0, 0.5));
      crosser = new SegmentCrosser (segs, neighs);
      Assert.IsTrue (crosser.Count <= 15, "Test #09: too many crossings!");
      Assert.IsTrue (crosser.Count >= 15, "Test #09: too few crossings!");

      segs.Add (new Segment (2, -1, 2, 3));
      crosser = new SegmentCrosser (segs, neighs);
      Assert.IsTrue (crosser.Count <= 17, "Test #10: too many crossings!");
      Assert.IsTrue (crosser.Count >= 17, "Test #10: too few crossings!");

      segs.Add (new Segment (2, -1, 2, 1));
      segs.Add (new Segment (2, 1, 2, 3));
      neighs.Add (new SegmentPair (segs[segs.Count - 1], segs[segs.Count - 2]));
      neighs.Add (new SegmentPair (segs[segs.Count - 1], segs[segs.Count - 3]));
      neighs.Add (new SegmentPair (segs[segs.Count - 2], segs[segs.Count - 3]));
      crosser = new SegmentCrosser (segs, neighs);
      Assert.IsTrue (crosser.Count <= 21, "Test #11: too many crossings!");
      Assert.IsTrue (crosser.Count >= 21, "Test #11: too few crossings!");

      segs.Add (new Segment (3, 2, 4, 2));
      crosser = new SegmentCrosser (segs, neighs);
      Assert.IsTrue (crosser.Count <= 23, "Test #12: too many crossings!");
      Assert.IsTrue (crosser.Count >= 23, "Test #12: too few crossings!");

      segs.Add (new Segment (4, 2, 5, 5));
      neighs.Add (new SegmentPair (segs[segs.Count - 1], segs[segs.Count - 2]));
      crosser = new SegmentCrosser (segs, neighs);
      Assert.IsTrue (crosser.Count <= 25, "Test #13: too many crossings!");
      Assert.IsTrue (crosser.Count >= 25, "Test #13: too few crossings!");

      segs.Add (new Segment (4, 2, 7, 5));
      segs.Add (new Segment (4, 2, 6, 0));
      neighs.Add (new SegmentPair (segs[segs.Count - 1], segs[segs.Count - 2]));
      crosser = new SegmentCrosser (segs, neighs);
      Assert.IsTrue (crosser.Count <= 33, "Test #14: too many crossings!");
      Assert.IsTrue (crosser.Count >= 33, "Test #14: too few crossings!");

      segs.Add (new Segment (4, 2, 6, 0));
      crosser = new SegmentCrosser (segs, neighs);
      Assert.IsTrue (crosser.Count <= 40, "Test #15: too many crossings!");
      Assert.IsTrue (crosser.Count >= 40, "Test #15: too few crossings!");

      segs.Clear ();
      neighs.Clear ();
      segs.Add (new Segment (0, 0, 2, 0));
      segs.Add (new Segment (0, 0, 2, 0));
      crosser = new SegmentCrosser (segs, neighs);
      Assert.IsTrue (crosser.Count <= 2, "Test #100: too many crossings!");
      Assert.IsTrue (crosser.Count >= 2, "Test #100: too few crossings!");

      segs.Add (new Segment (0, 1, 2, -1));
      segs.Add (new Segment (0, 1, 2, -1));
      crosser = new SegmentCrosser (segs, neighs);
      Assert.IsTrue (crosser.Count <= 8, "Test #101: too many crossings!");
      Assert.IsTrue (crosser.Count >= 8, "Test #101: too few crossings!");

      segs.Add (new Segment (0, -1, 1, 0));
      segs.Add (new Segment (0, -1, 1, 0));
      crosser = new SegmentCrosser (segs, neighs);
      Assert.IsTrue (crosser.Count <= 18, "Test #102: too many crossings!");
      Assert.IsTrue (crosser.Count >= 18, "Test #102: too few crossings!");

      segs.Add (new Segment (1, 0, 2, 1));
      segs.Add (new Segment (1, 0, 2, 1));
      crosser = new SegmentCrosser (segs, neighs);
      Assert.IsTrue (crosser.Count <= 32, "Test #103: too many crossings!");
      Assert.IsTrue (crosser.Count >= 32, "Test #103: too few crossings!");

      segs.Add (new Segment (0, 0, 1, 0));
      segs.Add (new Segment (0, 0, 1, 0));
      crosser = new SegmentCrosser (segs, neighs);
      Assert.IsTrue (crosser.Count <= 54, "Test #104: too many crossings!");
      Assert.IsTrue (crosser.Count >= 54, "Test #104: too few crossings!");

      segs.Add (new Segment (1, 0, 2, 0));
      segs.Add (new Segment (1, 0, 2, 0));
      crosser = new SegmentCrosser (segs, neighs);
      Assert.IsTrue (crosser.Count <= 80, "Test #105: too many crossings!");
      Assert.IsTrue (crosser.Count >= 80, "Test #105: too few crossings!");

      segs.Add (new Segment (1, 0, 2, 0));
      crosser = new SegmentCrosser (segs, neighs);
      Assert.IsTrue (crosser.Count <= 96, "Test #106: too many crossings!");
      Assert.IsTrue (crosser.Count >= 96, "Test #106: too few crossings!");

      segs.Add (new Segment (1, -1, 1, 1));
      segs.Add (new Segment (1, -1, 1, 1));
      segs.Add (new Segment (1, -1, 1, 1));
      crosser = new SegmentCrosser (segs, neighs);
      Assert.IsTrue (crosser.Count <= 141, "Test #107: too many crossings!");
      Assert.IsTrue (crosser.Count >= 141, "Test #107: too few crossings!");

      segs.Add (new Segment (-2, 0, 1, 0));
      crosser = new SegmentCrosser (segs, neighs);
      Assert.IsTrue (crosser.Count <= 157, "Test #108: too many crossings!");
      Assert.IsTrue (crosser.Count >= 157, "Test #108: too few crossings!");

      segs.Add (new Segment (1, 0, 2, -2));
      crosser = new SegmentCrosser (segs, neighs);
      Assert.IsTrue (crosser.Count <= 174, "Test #108: too many crossings!");
      Assert.IsTrue (crosser.Count >= 174, "Test #108: too few crossings!");

      segs.Add (new Segment (1, -2, 1, 0));
      crosser = new SegmentCrosser (segs, neighs);
      Assert.IsTrue (crosser.Count <= 195, "Test #109: too many crossings!");
      Assert.IsTrue (crosser.Count >= 195, "Test #109: too few crossings!");

      segs.Add (new Segment (1, 2, 1, 0));
      crosser = new SegmentCrosser (segs, neighs);
      Assert.IsTrue (crosser.Count <= 217, "Test #110: too many crossings!");
      Assert.IsTrue (crosser.Count >= 217, "Test #110: too few crossings!");
    } 
  }
}
